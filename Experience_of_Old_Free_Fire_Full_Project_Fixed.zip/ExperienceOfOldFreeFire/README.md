# Experience of Old Free Fire — Native Unreal Engine Project

This is a native Unreal Engine 5.4 C++ offline-game development project. It is not a website or browser game.

## Current source state

The project includes a runtime-generated low-poly island blockout, player movement/combat foundations, bots, loot, safe zone, BR/Clash Squad logic, profile/store/royale metadata, a native lobby/menu framework, map selection, character/pet ability foundations, and mobile action-button source.

## Validate source/configuration

Run `python Tools/validate_project.py` from this directory. This performs static checks only.

## Build status

No Unreal Engine 5.4/UnrealBuildTool was available in the generation environment. This ZIP is source code and configuration, **not a built APK**. Compile in Unreal Engine, fix any engine/compiler errors, package Android ARM64, install and test on a device before calling the game playable.

See `MAJOR_UPDATE_REPORT.md` and `Docs/MASTER_CHECKLIST_STATUS.md` for what is implemented versus still incomplete.


## Visual quality pass (source-level, not runtime-verified)
- Replaced the hard cube-shaped tree canopy proxy with instanced rounded sphere foliage and a green material tint where the engine basic-shape material exposes a color parameter.
- Added Android-oriented scalability profiles for view distance, AA, shadows, and texture filtering.
- Enabled mobile HDR/MSAA-related renderer settings for a quality/performance trade-off to be profiled on target devices.
- This remains a prototype greybox. These changes do not recreate Garena Free Fire's proprietary assets or prove parity with the 2019 game. Unreal compilation, Android packaging, and device profiling are still required.
