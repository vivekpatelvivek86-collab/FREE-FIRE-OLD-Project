Experience of Old Free Fire — Native Unreal Engine Android Game Project

This is a native Unreal Engine C++ project source package. It is not a website and contains no HTML/React browser game. It is NOT an APK and has not been compiled or device-tested here.

Added native meta-game foundation: modes catalog, profile/progression, store inventory/purchases, equipment selection, pets/characters as catalog categories, settings, and local SaveGame persistence. See ExperienceOfOldFreeFire/Docs/ADVANCED_SYSTEMS_ADDED.md.

Still required before calling it a complete game: implement and visually wire the UMG screens, build actual gameplay for each mode, add original/licensed 3D characters/pets/weapons/maps/animations/audio, configure Android icons/input/performance, then compile/package and test on devices. Do not treat placeholder catalog entries as actual finished content.
