# Experience of Old Free Fire — Identity, settings and comparison

## Identity changes in this source update
- Player-facing lobby title and Android application display name: `Experience of Old Free Fire`.
- Android package ID: `com.experienceofoldfreefire.game`.
- Save slot renamed to `Experience_of_Old_Free_Fire_Profile`.
- Map page explicitly lists `BERMUDA ISLAND — SELECT` and `PURGATORY ISLAND — SELECT`.
- Unreal's internal module remains `ExperienceOfOldFreeFire` because renaming a UE C++ module safely requires changing target/build/module files together and compiling in Unreal Engine. It is an internal source identifier, not the app's display name.

## Settings expanded
Added persistent settings fields and menu controls for master/music/SFX levels, look/aim sensitivity, aim assist, auto pickup, left fire button, quick weapon switch, auto parachute, graphics/shadow/texture quality, FPS cap, low-power mode, vibration, damage numbers, hit markers, and reset-to-defaults. Settings are saved locally. Important: options that need final audio, graphics, or input integration are stored in the project but are not all connected to actual runtime systems yet.

## Bermuda location
Open the in-game lobby and tap `SELECT MAP` or `MAPS`, then choose `BERMUDA ISLAND — SELECT`. Current Bermuda is a procedural greybox layout, not the finished detailed island map from Free Fire.

## Honest comparison: Free Fire (2019 era) vs Experience of Old Free Fire source build
| Feature | Free Fire around 2019 | Experience of Old Free Fire current source build |
|---|---|---|
| Official commercial game | Yes, Garena's released game | No; independent prototype, not official or endorsed |
| Online multiplayer | Supported | Not implemented; current target is offline |
| Visual quality | Authored 3D assets, animations, effects and polished UI | Primitive/greybox world and proxy characters; UI is native UMG source but not runtime-tested |
| Bermuda map | Authored production map with locations/buildings | Selectable procedural greybox variant; not a full map recreation |
| Battle Royale | Mature 2019-era gameplay | Native gameplay foundations and bots; not feature-complete or balanced |
| Clash Squad | Official mode/gameplay | Source foundations only; not fully polished/tested |
| Characters/pets | Official character/pet models and tuned abilities | Data-driven placeholder catalog and basic ability/passive foundations |
| Settings | Production options wired to actual systems | Expanded saved options; several still need runtime integration |
| APK/device validation | Released and tested by publisher | No APK built and no Unreal compile/device test performed in this environment |

This is a source-code update, not a claim that every requested feature is complete. It uses no copied proprietary game assets. Unreal Engine 5.4 must compile this project before any build success can be confirmed.
