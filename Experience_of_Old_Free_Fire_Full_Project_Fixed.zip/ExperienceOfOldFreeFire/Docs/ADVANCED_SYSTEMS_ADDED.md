# Experience of Old Free Fire — native meta-game systems pass

This pass adds a native Unreal C++ progression subsystem, not a finished or packaged game. It provides a code foundation for:

- Seven selectable mode identifiers: BR Classic, BR Ranked, Clash Squad, Ranked Clash Squad, Rush Hour, Training, and Lone Wolf.
- Local player profile: nickname validation, level/XP, currency, BR and Clash Squad match/win counters.
- A data-driven starter catalog covering character, pet, outfit, weapon skin, emote, loot crate, and voucher categories.
- Coin/diamond purchase checks, ownership, one equipped item per category, and basic inventory persistence.
- Audio, look/aim sensitivity, aim assist, auto-pickup, left fire button, and graphics-quality settings with range clamping.
- Local save/load via Unreal SaveGame.

## Important limits

These are **systems/data foundations**, not the full Free Fire 2019 content recreated. The catalog entries are original placeholders, not actual Free Fire characters, pets, costumes, weapons, animations, or sounds. Modes are selectable identifiers only: each mode still needs its own gameplay rules, matchmaking/round logic, UI, maps and assets. Store/profile/vault/pet/character/settings screens are not yet implemented as finished UMG screens. Online multiplayer, server authority, anti-cheat, purchases, and Android packaging are not implemented. No Unreal build or device test was run in this environment.

## Integration

Get the subsystem from `UGameInstance::GetSubsystem<UBRMetaProgressionSubsystem>()`. Build menu widgets in UMG/Blueprint and bind their buttons to `SelectMode`, `PurchaseItem`, `EquipItem`, `SetNickname`, and `SetSettings`. Add original/licensed asset references to catalog data before shipping.
