# Advanced Gameplay Pass

Implemented in C++ source:
- Sprint start/stop (keyboard and Blueprint-callable for mobile UI).
- Crouch toggle.
- Aim mode with tighter camera arm and reduced movement speed.
- Medkit inventory and healing.
- Reserve ammunition with bounded pickup API.
- Reload consumes reserve ammo and loads only the missing rounds.
- Bot yaw interpolation toward the player while pursuing.

Not yet implemented/verified: full 3D island assets, polished animations, full loot spawning, parachute, complete match-state/win flow, real networking, Android package, and compiled build. Compile and test in Unreal Engine before treating as playable.
