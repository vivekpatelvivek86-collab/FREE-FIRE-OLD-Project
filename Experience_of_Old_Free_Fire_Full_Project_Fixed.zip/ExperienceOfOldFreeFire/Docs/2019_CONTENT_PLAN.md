# FF 2019-inspired content pass (native Unreal project)

This pass adds native C++ metadata for the classic 2019-era mode list and Luck Royale categories. It is not an original Free Fire asset dump and does not reproduce proprietary maps, characters, audio, UI art, or item names.

## Mode registry currently exposed to native UI/Blueprints
- Classic Battle Royale: 50 target participants, safe-zone rules expected.
- Ranked Battle Royale: ranked flag and 50 target participants; actual rank/season logic still required.
- Clash Squad: 4v4 metadata; round economy and full round state machine still required.
- Ranked Clash Squad: ranked flag; ranked scoring still required.
- Rush Hour: BR-style fast match metadata; accelerated rules still required.
- Training Ground: solo practice metadata; weapon range and target props still required.
- Lone Wolf: included as an inspired extension, not a 2019 launch-era mode.

## 2019-era Luck Royale categories
- Gold Royale
- Diamond Royale
- Weapon Royale
- Incubator
- Legacy Returns

The code exposes offer metadata only. It does not yet implement a complete spin/reward animation, probability tables, pity rules, or real-money purchases. No real-money purchase integration is included.

## Map plan
- Bermuda-inspired original island greybox: primary target. Required districts: coastal landing area, residential blocks, industrial yard, central town, hill/radio landmark, bridges, roads, loot interiors, cover, and safe-zone bounds.
- Purgatory-inspired original island greybox: secondary target. Required districts: river crossings, settlement clusters, elevated terrain, and long-range sightlines.
- Do not use extracted Free Fire map meshes/textures/audio. Build original greybox geometry and replace with original/licensed art.

## Honest implementation status
The map IDs and mode definitions are data only. The current project ZIP has not been compiled with Unreal Engine and these mode definitions do not make every mode playable by themselves. The existing GameMode still primarily runs its offline bot-spawn flow. Each mode needs its own round/phase rules, map geometry, spawn points, loot, HUD, win conditions, and testing. Android packaging/device performance is unverified.
