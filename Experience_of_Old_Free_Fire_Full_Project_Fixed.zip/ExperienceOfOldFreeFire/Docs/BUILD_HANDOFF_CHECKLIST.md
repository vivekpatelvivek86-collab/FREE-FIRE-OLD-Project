# Build handoff checklist

This project is ready for a **first external compile/package attempt**, not yet confirmed build-ready at runtime.

- Project descriptor and runtime/editor target rules are present.
- Android package ID, app display name, landscape orientation, minimum API and ARM64 setting are configured.
- Android launcher icons exist for mdpi through xxxhdpi.
- Build spec is in `Build/Android/BuildSpec.json`.
- Windows and macOS/Linux RunUAT wrappers are in `Build/Android/`.
- Environment diagnostic: `python Tools/android_build_preflight.py`.
- Static source/config validation: `python Tools/validate_project.py`.
- Build dependencies and setup notes: `Docs/ANDROID_BUILD_REQUIREMENTS.md`.

**Not yet proven:** C++ compilation, asset cooking, APK packaging, install, audio playback or in-game functionality. The first Unreal compile may reveal source errors that static validation cannot detect; fix those before expecting a test APK.
