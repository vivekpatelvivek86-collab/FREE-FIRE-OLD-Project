# Automatic Workflow — Phase 4: Gameplay and AI Pass

## Implemented in source
- Bot target selection now observes an awareness radius, avoiding target acquisition across the entire map.
- Bots now add lightweight lateral movement and adjust their approach when near their attack range. This is intentionally simple, native C++ prototype AI, not production shooter AI.
- Training mode no longer advances the normal match timeout; the practice space can remain open until the player leaves/restarts it.
- Static validation was expanded to cover these code paths.

## Remaining limitations
- These changes have not been compiled with Unreal Engine in this environment.
- Runtime AI movement, collision, hit traces, and mobile performance still require Unreal Editor/device testing.
- Characters, environments, and effects remain prototype/greybox quality.
