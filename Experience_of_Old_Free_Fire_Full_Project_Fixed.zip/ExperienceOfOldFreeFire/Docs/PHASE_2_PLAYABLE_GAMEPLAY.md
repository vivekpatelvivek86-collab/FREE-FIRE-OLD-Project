# Phase 2 — Playable World & Combat Source Pass

Implemented in source for this phase:
- Player armor with bounded damage absorption and armor pickup support.
- Four weapon profiles retained; shotgun fires a six-pellet spread, SMG has higher spread/fire rate, rifle/sniper have distance falloff, and high impacts apply a headshot multiplier.
- Reload consumes reserve ammo and pickup increases reserve ammo.
- Loot has separate Ammo, Medkit, Armor and WeaponUpgrade types.
- Bot target refresh is throttled to 0.35 seconds rather than scanning every frame; bots can attack opposing teams and drop a random ammo/medkit/armor pickup when eliminated.
- Loot count scales by selected mode; training gets a smaller set, full BR gets a larger set.
- Empty-level player spawn is moved away from the central blockout structure.
- BR end condition counts living bots rather than relying only on actor array length.

## Verification boundary
Static source checks and archive integrity can be run in this environment. Unreal Engine / UnrealBuildTool is not installed here, so this does **not** establish successful C++ compilation, editor runtime behavior, packaged Android behavior, or device performance. The map remains a greybox made from engine primitive meshes; no production-grade art assets were added.
