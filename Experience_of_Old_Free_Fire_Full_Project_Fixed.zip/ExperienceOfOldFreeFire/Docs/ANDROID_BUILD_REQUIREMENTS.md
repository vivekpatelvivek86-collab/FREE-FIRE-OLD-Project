# Experience of Old Free Fire — Android build requirements and handoff

This document is the build handoff for creating a **test APK** from this native Unreal Engine project. It is not evidence that a build has already succeeded.

## Project identity

- Unreal project: `ExperienceOfOldFreeFire.uproject`
- Required engine association: **Unreal Engine 5.4** (`EngineAssociation: 5.4`)
- Game target: `ExperienceOfOldFreeFire`
- Build configuration: `Development` (for initial testing)
- Platform / ABI: Android / **ARM64 (`arm64-v8a`)**
- Package ID: `com.experienceofoldfreefire.game`
- App label: `Experience of Old Free Fire`
- Orientation: Landscape
- Minimum Android API: 26 (Android 8.0)
- Target Android API configured in project: 35
- Google Play services: disabled

The machine doing the build needs sufficient free disk space for the Unreal Engine installation, Android toolchain, shader/cook intermediates and packaged output. A practical starting point is 100 GB free; more may be needed depending on the engine install and derived data cache.

## Required software

1. **Unreal Engine 5.4**, including Android platform support and Unreal Automation Tool (RunUAT).
2. A C++ compiler/toolchain supported by the installed UE 5.4 build (Visual Studio 2022 with the required C++ desktop/game development components on Windows; the appropriate Xcode/Clang toolchain on macOS where supported).
3. Android SDK, Android NDK, command-line/build tools and JDK versions that the **specific UE 5.4 installation** recognizes.
4. Python 3 only for the included project static validator and environment preflight helper; Python is not used to compile the game.
5. An Android ARM64 device for installation and gameplay testing, plus `adb` if testing over USB.

### Important version rule

Do not install arbitrary latest SDK/NDK/JDK versions and assume UE 5.4 will accept them. Open the engine's Android setup/Turnkey workflow (commonly `Engine/Extras/Android/SetupAndroid.bat` on Windows) and use the versions it recommends for that exact engine build. The project currently targets API 35 in `DefaultEngine.ini`; if UE 5.4's installed toolchain reports that target API as unsupported, adjust the target SDK to a supported value for a sideload test build and rerun validation. Keep min API 26 unless a deliberate compatibility change is made.

## First-time setup checklist

- [ ] Install Unreal Engine 5.4 and verify that the editor opens.
- [ ] Install the required native C++ compiler/toolchain for the host OS.
- [ ] Run UE's Android setup/Turnkey process and accept its recommended SDK/NDK/JDK setup.
- [ ] In Unreal Editor, open `ExperienceOfOldFreeFire.uproject`, allow project/module processing, and resolve any C++ or asset errors.
- [ ] In **Project Settings → Platforms → Android**, confirm SDK paths, ARM64 support, package name, app label and signing settings.
- [ ] Run `python Tools/android_build_preflight.py` and confirm the engine and Android paths are detected.
- [ ] Run `python Tools/validate_project.py`; this is a static check only.
- [ ] Run the matching script below, or use Unreal Editor's Package Project → Android (ASTC/ETC2 chosen according to actual assets/device).
- [ ] Confirm the APK exists in the archive output and inspect UAT logs for errors.
- [ ] Install on a real device; test startup, lobby/menu, audio, touch controls, mode selection, match start/end, bots, weapons, map generation, pause/restart and repeated launches.

## Build from Windows

1. Set `UE_ROOT` to the root folder of the Unreal Engine 5.4 installation, for example `C:\Program Files\Epic Games\UE_5.4`.
2. Open a Developer Command Prompt / PowerShell with the required C++ tools installed.
3. From the project root, run:

   `Build\\Android\\BuildAndroidDevelopment.bat`

The script invokes `RunUAT BuildCookRun` for Android ARM64 and writes the archive under `Build/Android/Archive`. It exits non-zero if RunUAT fails. It does not claim device testing.

## Build from macOS/Linux (where UE Android packaging is supported)

Set `UE_ROOT` to the Unreal Engine 5.4 root, then run:

`bash Build/Android/BuildAndroidDevelopment.sh`

## If the build fails

- Save the full terminal output and the UAT log path shown by Unreal.
- Common failure classes: unsupported SDK/NDK/JDK version, missing Android platform/license, missing host C++ toolchain, C++ compile errors, missing Unreal assets, cook errors, insufficient disk space, signing configuration or Android packaging settings.
- Fix the first real error, rerun static validation, then repeat the build. Do not report an APK as generated unless the APK file exists.

## Current limitations to expect during test

This is still a source-level prototype with procedural/greybox environments and proxy actors. Static validation cannot establish that it compiles or that the gameplay works. The `Content/Audio/FFOld_Lobby_Ringtone.wav` file is a raw WAV source file; Unreal normally plays cooked `USoundWave` assets, so import it through the Unreal Editor as a Sound Wave asset and verify the `/Game/Audio/FFOld_Lobby_Ringtone` reference before expecting lobby music to play in a packaged APK.

## Test report template

- Engine version:
- Host OS:
- SDK / NDK / JDK versions reported by UE:
- Static validation result:
- UAT result and log path:
- APK full path and size:
- Device model / Android version:
- Installed and launched: yes/no
- Gameplay checks passed:
- Bugs / crash logs:
