# Automatic Workflow Phase 5 — Lobby Audio & Release Readiness

## Implemented in source
- Added an original synthesized retro-futuristic lobby ringtone at `Content/Audio/FFOld_Lobby_Ringtone.wav`. It is newly created for this project and is not ripped from Free Fire.
- Frontend attempts to load the imported Unreal asset `/Game/Audio/FFOld_Lobby_Ringtone` and play it as looping lobby music.
- Lobby audio gain follows the saved `MasterVolume × MusicVolume` settings.
- Settings includes a replay control and music volume decrease control.
- Lobby audio component is stopped when the frontend widget is destroyed (for example, when starting a match).

## Important Unreal asset step
The WAV is source content. Open the project in the target Unreal Engine version and let the Content Browser import it so Unreal creates the corresponding `.uasset`; then compile/package. This environment does not contain Unreal Engine/UnrealBuildTool, so the audio import, C++ compile, APK package and runtime playback are not verified here.

## Validation
Run `python3 Tools/validate_project.py`. Static checks verify the source wiring and presence of the WAV, but cannot prove runtime playback.
