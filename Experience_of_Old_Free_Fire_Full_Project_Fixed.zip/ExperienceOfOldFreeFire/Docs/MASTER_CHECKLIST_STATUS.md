# Master checklist — source update status

Legend: `SOURCE` = code/configuration exists; `PARTIAL` = foundation only; `UNVERIFIED` = requires Unreal runtime/device; `MISSING` = not implemented.

## Native project and startup
- [x] Native Unreal C++ module and Android configuration — SOURCE
- [x] Lobby-first startup and Start button — SOURCE; UNVERIFIED in engine
- [x] Mode selection persisted and applied on Start — SOURCE; UNVERIFIED in engine
- [x] Selectable Bermuda-inspired/Purgatory-inspired procedural layouts — PARTIAL; not final-quality maps
- [ ] Unreal Engine C++ compile — MISSING / environment unavailable
- [ ] Android APK package and install test — MISSING

## World and combat
- [x] Runtime island blockout, primitive buildings, cover and foliage proxies — PARTIAL
- [x] Instanced mesh component for blockout performance — SOURCE; UNVERIFIED at runtime
- [x] Player movement, shooting traces, reload, armor/health and weapon profiles — SOURCE; UNVERIFIED
- [x] Per-weapon magazine/reserve values on weapon switch — SOURCE; UNVERIFIED
- [x] Loot pickup actors and spawn code — SOURCE; UNVERIFIED
- [x] Safe-zone damage and BR end conditions — SOURCE; UNVERIFIED
- [ ] Authored detailed map art, interiors/furniture, proper materials, terrain/water assets — MISSING
- [ ] Robust bot navigation, cover tactics, parachuting, smart looting and difficulty — MISSING
- [ ] Production weapon models, animations, audio, grenades/attachments — MISSING/PARTIAL

## Modes
- [x] BR bot-count configuration and safe-zone setup — SOURCE; UNVERIFIED
- [x] Clash Squad team/round/win logic — SOURCE; UNVERIFIED
- [ ] Full Clash Squad economy/buy phase, polished scoreboard/results — MISSING
- [ ] All modes runtime-playtested and balanced — UNVERIFIED

## Characters, pets and frontend
- [x] Interactive native UMG page navigation — SOURCE; UNVERIFIED
- [x] Store purchase/equip, Vault list, Luck Royale spin actions — SOURCE foundation; UNVERIFIED
- [x] Character ability activation and cooldown — SOURCE foundation; UNVERIFIED
- [x] Pet passive definitions and sphere-proxy follower — SOURCE foundation; UNVERIFIED
- [ ] Production character/pet meshes, animation blueprints and art — MISSING
- [ ] Full visual polish, transitions, complete settings/audio application and results screens — MISSING/PARTIAL

## Mobile/release
- [x] Virtual joystick config and native touch action buttons — SOURCE; UNVERIFIED
- [x] Android icon resources, landscape and package name — CONFIGURATION
- [ ] Unreal compile, Android packaging, device input test, performance profiling and crash fixes — MISSING
- [ ] Final release build — MISSING

## Scope note
Online multiplayer remains intentionally deferred, as previously agreed. This checklist marks source implementation separately from runtime-tested behavior; static checks are not treated as gameplay tests.
