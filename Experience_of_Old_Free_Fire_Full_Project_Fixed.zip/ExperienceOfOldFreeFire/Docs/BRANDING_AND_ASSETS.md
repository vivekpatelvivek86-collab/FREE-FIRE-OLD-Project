# Free Fire Old — branding and graphics

Included in `Content/Branding/`:
- `ExperienceOfOldFreeFire_Logo.png` — full landscape logo artwork
- `ExperienceOfOldFreeFire_AppIcon_1024.png` — square app-icon concept
- `ExperienceOfOldFreeFire_AppIcon_512.png` — smaller icon concept

These are visual branding assets only; they are not automatically wired into Unreal's Android launcher icon or any in-game UI. The launcher icon must be configured in Project Settings / Android packaging, and the logo should be imported into Unreal as a Texture2D and placed in a UMG widget.

## Graphics plan
Use original or properly licensed assets for island terrain, vegetation, buildings, characters, clothes, weapons, VFX, UI and audio. Do not extract proprietary Free Fire/Garena files. A downloaded asset is not automatically free to use; check its license and attribution requirements.

## Current project status
This is still a C++ development scaffold. It is not a complete playable game and has not been compiled or packaged into an APK in this environment. It does not yet include a finished island, final character models, animations, full lobby UI or mobile controls.
