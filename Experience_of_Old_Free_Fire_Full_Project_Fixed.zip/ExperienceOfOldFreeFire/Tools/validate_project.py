#!/usr/bin/env python3
"""Static sanity checks for FF 2019 Full native Unreal source. Does not replace UBT compilation."""
from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
checks=[]
def check(name, ok, detail=''):
    checks.append((name, bool(ok), detail))

try:
    project=json.loads((ROOT/'ExperienceOfOldFreeFire.uproject').read_text())
    check('uproject JSON parses', True)
    check('ExperienceOfOldFreeFire runtime module declared', any(m.get('Name')=='ExperienceOfOldFreeFire' and m.get('Type')=='Runtime' for m in project.get('Modules',[])))
except Exception as e:
    check('uproject JSON parses', False, str(e))

# Build handoff artifacts: these are recipes/configuration, not proof of a successful build.
try:
    build_spec=json.loads((ROOT/'Build'/'Android'/'BuildSpec.json').read_text())
    check('Android BuildSpec JSON parses', True)
    check('BuildSpec matches Unreal 5.4 project', build_spec.get('engineAssociation')=='5.4' and build_spec.get('uproject')=='ExperienceOfOldFreeFire.uproject')
    check('BuildSpec Android ARM64 and package ID', 'arm64-v8a' in build_spec.get('architectures',[]) and build_spec.get('packageName')=='com.experienceofoldfreefire.game')
except Exception as e:
    check('Android BuildSpec JSON parses', False, str(e))
check('Android requirements guide exists', (ROOT/'Docs'/'ANDROID_BUILD_REQUIREMENTS.md').is_file())
check('build handoff checklist exists', (ROOT/'Docs'/'BUILD_HANDOFF_CHECKLIST.md').is_file())
check('Windows Android build wrapper exists', (ROOT/'Build'/'Android'/'BuildAndroidDevelopment.bat').is_file())
check('Unix Android build wrapper exists', (ROOT/'Build'/'Android'/'BuildAndroidDevelopment.sh').is_file())

src=ROOT/'Source'/'ExperienceOfOldFreeFire'
headers=list((src/'Public').glob('*.h'))
cpps=list((src/'Private').glob('*.cpp'))
check('native public headers present', len(headers)>=8, str(len(headers)))
check('native cpp implementation files present', len(cpps)>=8, str(len(cpps)))
check('native-only project has no web prototype files', not any(p.suffix.lower() in {'.html','.jsx','.tsx'} for p in ROOT.rglob('*') if p.is_file()))

all_names={p.name for p in src.rglob('*') if p.is_file()}
for name in ['BRFrontendWidget.h','BRPetCompanion.h','BRWorldBuilderActor.h','BRMetaProgressionSubsystem.h','ExperienceOfOldFreeFireGameMode.h']:
    check(f'{name} exists', name in all_names)

# Strip comments and quoted strings, then perform a conservative delimiter-balance scan.
def stripped(text):
    text=re.sub(r'/\*.*?\*/',' ',text,flags=re.S)
    text=re.sub(r'//[^\n]*',' ',text)
    text=re.sub(r'R"\([^)]*\)"',' ',text)
    text=re.sub(r'"(?:\\.|[^"\\])*"','""',text)
    text=re.sub(r"'(?:\\.|[^'\\])*'","''",text)
    return text
for f in headers+cpps:
    t=stripped(f.read_text(errors='replace'))
    ok=True; stack=[]; pairs={')':'(',']':'[','}':'{'}
    for ch in t:
        if ch in '([{': stack.append(ch)
        elif ch in ')]}':
            if not stack or stack.pop()!=pairs[ch]: ok=False; break
    if stack: ok=False
    check(f'delimiter balance: {f.name}', ok)

# Verify local includes resolve by basename somewhere in module source.
for f in cpps+headers:
    text=f.read_text(errors='replace')
    for inc in re.findall(r'^\s*#include\s+"([^"]+)"',text,re.M):
        base=Path(inc).name
        if base.endswith('.generated.h'):
            continue
        if base in all_names:
            check(f'local include {base} from {f.name}', True)
        elif inc.startswith(('BR','ExperienceOfOldFreeFire')):
            check(f'local include {base} from {f.name}', False, 'not found in module source')

engine=(ROOT/'Config'/'DefaultEngine.ini').read_text(errors='replace')
inputs=(ROOT/'Config'/'DefaultInput.ini').read_text(errors='replace')
check('Android package identifier configured', 'PackageName=com.experienceofoldfreefire.game' in engine)
check('landscape orientation configured', 'Orientation=Landscape' in engine)
check('virtual joystick configured', 'DefaultVirtualJoysticks' in engine)
check('ability input configured', 'ActionName="Ability"' in inputs)

checks_code={
 'interactive lobby menu': ('StartOfflineMatch' in (src/'Private'/'BRFrontendWidget.cpp').read_text()),
 'mode selection action': ('SelectMode(M)' in (src/'Private'/'BRFrontendWidget.cpp').read_text()),
 'map selection persisted': ('Save->SelectedMap=SelectedMap' in (src/'Private'/'BRMetaProgressionSubsystem.cpp').read_text()),
 'weapon-specific ammo arrays': ('WeaponMagazines' in (src/'Private'/'BRPlayerCharacter.cpp').read_text() and 'WeaponReserves' in (src/'Private'/'BRPlayerCharacter.cpp').read_text()),
 'character ability implementation': ('ActivateSelectedAbility' in (src/'Private'/'BRPlayerCharacter.cpp').read_text()),
 'pet companion implementation': (src/'Private'/'BRPetCompanion.cpp').exists(),
 'reflected UMG action button dispatcher': (src/'Private'/'BRActionButton.cpp').exists() and 'AddDynamic' in (src/'Private'/'BRActionButton.cpp').read_text(),
 'map variant selection': ('bPurgatoryStyle' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text() and 'SelectMap' in (src/'Private'/'BRMetaProgressionSubsystem.cpp').read_text()),
 'mobile action buttons': ('TouchFire' in (src/'Private'/'BRGameHUDWidget.cpp').read_text()),
 'instanced world mesh optimization': ('UInstancedStaticMeshComponent' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text()),
 'match waits for Start action': ('!bGameStarted' in (src/'Private'/'ExperienceOfOldFreeFireGameMode.cpp').read_text()),
 'rounded instanced foliage canopies': ('AddCanopy' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text() and 'Sphere.Sphere' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text()),
 'Android scalability profiles present': (ROOT/'Config'/'DefaultScalability.ini').is_file(),
 'mobile quality renderer options present': ('r.MobileMSAA=4' in engine and 'r.MobileHDR=True' in engine),
 'training has dedicated world layout': ('SelectedMode == EBRGameMode::Training' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text() and 'Four firing lanes' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text()),
 'lone wolf has dedicated arena layout': ('SelectedMode == EBRGameMode::LoneWolf' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text() and 'Mirrored sides' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text()),
 'foliage canopy helper is implemented': ('void ABRWorldBuilderActor::AddCanopy' in (src/'Private'/'BRWorldBuilderActor.cpp').read_text()),
 'mode-specific player spawn': ('SetActorLocation(FVector(-4200.f, -2400.f, 170.f))' in (src/'Private'/'ExperienceOfOldFreeFireGameMode.cpp').read_text()),
 'Android low/mid/high device profiles configured': all(f'[{level} DeviceProfile]' in (ROOT/'Config'/'DefaultDeviceProfiles.ini').read_text() for level in ('Android_Low','Android_Mid','Android_High')),
 'Android build preflight diagnostic exists': (ROOT/'Tools'/'android_build_preflight.py').is_file() and 'does not compile, package' in (ROOT/'Tools'/'android_build_preflight.py').read_text(),
 'bot awareness range limits target selection': ('AwarenessRange' in (src/'Private'/'BRBotCharacter.cpp').read_text() and 'FMath::Square(AwarenessRange)' in (src/'Private'/'BRBotCharacter.cpp').read_text()),
 'bot combat strafe behavior': ('StrafeSign' in (src/'Private'/'BRBotCharacter.cpp').read_text() and 'CombatMoveScale' in (src/'Private'/'BRBotCharacter.cpp').read_text()),
 'original lobby ringtone source asset exists': (ROOT/'Content'/'Audio'/'FFOld_Lobby_Ringtone.wav').is_file(),
 'lobby ringtone playback is wired to frontend': ('StartLobbyRingtone' in (src/'Private'/'BRFrontendWidget.cpp').read_text() and 'SpawnSound2D' in (src/'Private'/'BRFrontendWidget.cpp').read_text()),
 'lobby ringtone uses saved master and music volume': ('Settings.MasterVolume * Settings.MusicVolume' in (src/'Private'/'BRFrontendWidget.cpp').read_text()),
 'audio settings update current ringtone volume': ('UpdateLobbyRingtoneVolume();' in (src/'Private'/'BRFrontendWidget.cpp').read_text()),
 'lobby ringtone replay control exists': ('Replay classic lobby ringtone' in (src/'Private'/'BRFrontendWidget.cpp').read_text()),
 'training mode ignores match timeout': ('persistent practice space' in (src/'Private'/'ExperienceOfOldFreeFireGameMode.cpp').read_text() and 'GetSelectedMode() == EBRGameMode::Training) return;' in (src/'Private'/'ExperienceOfOldFreeFireGameMode.cpp').read_text()),
}
for n,ok in checks_code.items(): check(n,ok)

icon_root=ROOT/'Build'/'Android'/'res'
for density in ['mipmap-mdpi','mipmap-hdpi','mipmap-xhdpi','mipmap-xxhdpi','mipmap-xxxhdpi']:
    check(f'launcher icon {density}', (icon_root/density/'ic_launcher.png').is_file())

passed=sum(1 for _,ok,_ in checks if ok)
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
print(f'RESULT: {passed}/{len(checks)} static checks passed')
print('NOTE: This script does not compile Unreal C++ or validate runtime/gameplay/APK behavior.')
sys.exit(0 if passed==len(checks) else 1)
