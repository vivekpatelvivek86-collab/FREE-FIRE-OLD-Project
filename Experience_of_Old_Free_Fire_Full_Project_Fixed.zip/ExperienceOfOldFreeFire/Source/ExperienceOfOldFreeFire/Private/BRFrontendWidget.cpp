#include "BRFrontendWidget.h"
#include "BRActionButton.h"
#include "BRMetaProgressionSubsystem.h"
#include "BRPlayerCharacter.h"
#include "ExperienceOfOldFreeFireGameMode.h"
#include "Blueprint/WidgetTree.h"
#include "Components/VerticalBox.h"
#include "Components/HorizontalBox.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "Components/Border.h"
#include "Components/ScrollBox.h"
#include "Components/AudioComponent.h"
#include "Sound/SoundWave.h"
#include "UObject/ConstructorHelpers.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"

void UBRFrontendWidget::NativeConstruct()
{
    Super::NativeConstruct();
    if (!WidgetTree) return;
    UBorder* Backdrop=WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass(),TEXT("Backdrop"));
    Backdrop->SetPadding(FMargin(18.f));
    Backdrop->SetBrushColor(FLinearColor(0.018f,0.027f,0.04f,0.96f));
    RootBox=WidgetTree->ConstructWidget<UVerticalBox>(UVerticalBox::StaticClass(),TEXT("RootMenu"));
    Backdrop->SetContent(RootBox); WidgetTree->RootWidget=Backdrop;
    ContentScroll=WidgetTree->ConstructWidget<UScrollBox>(UScrollBox::StaticClass(),TEXT("MenuScroll"));
    RootBox->AddChild(ContentScroll);
    StartLobbyRingtone();
    RebuildPage();
}
void UBRFrontendWidget::NativeDestruct()
{
    if (LobbyMusicComponent) { LobbyMusicComponent->Stop(); LobbyMusicComponent = nullptr; }
    Super::NativeDestruct();
}
void UBRFrontendWidget::StartLobbyRingtone()
{
    if (!LobbyRingtone) LobbyRingtone = Cast<USoundWave>(StaticLoadObject(USoundWave::StaticClass(), nullptr, TEXT("/Game/Audio/FFOld_Lobby_Ringtone.FFOld_Lobby_Ringtone")));
    if (!LobbyRingtone || LobbyMusicComponent) return;
    LobbyRingtone->bLooping = true;
    UBRMetaProgressionSubsystem* Meta = GetGameInstance() ? GetGameInstance()->GetSubsystem<UBRMetaProgressionSubsystem>() : nullptr;
    const FBRGameSettings Settings = Meta ? Meta->GetSettings() : FBRGameSettings{};
    LobbyMusicComponent = UGameplayStatics::SpawnSound2D(this, LobbyRingtone, Settings.MasterVolume * Settings.MusicVolume, 1.f, 0.f, nullptr, true, false);
    if (LobbyMusicComponent) LobbyMusicComponent->bIsUISound = true;
}
void UBRFrontendWidget::UpdateLobbyRingtoneVolume()
{
    if (LobbyMusicComponent) {
        UBRMetaProgressionSubsystem* Meta = GetGameInstance() ? GetGameInstance()->GetSubsystem<UBRMetaProgressionSubsystem>() : nullptr;
        const FBRGameSettings Settings = Meta ? Meta->GetSettings() : FBRGameSettings{};
        LobbyMusicComponent->SetVolumeMultiplier(Settings.MasterVolume * Settings.MusicVolume);
    }
}
void UBRFrontendWidget::ShowPage(EBRFrontendPage Page) { CurrentPage=Page; RebuildPage(); }
void UBRFrontendWidget::AddLabel(const FString& Text, int32 Size)
{
    if (!ContentScroll) return;
    UTextBlock* T=WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
    T->SetText(FText::FromString(Text)); T->SetColorAndOpacity(FSlateColor(FLinearColor(0.96f,0.82f,0.42f,1.f)));
    FSlateFontInfo Font=T->GetFont(); Font.Size=Size; T->SetFont(Font); ContentScroll->AddChild(T);
}
void UBRFrontendWidget::AddButton(const FString& Text, TFunction<void()> Action)
{
    if (!ContentScroll) return;
    UBRActionButton* B=WidgetTree->ConstructWidget<UBRActionButton>(UBRActionButton::StaticClass());
    B->SetBackgroundColor(FLinearColor(0.12f,0.16f,0.20f,1.f));
    UTextBlock* Label=WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass());
    Label->SetText(FText::FromString(Text)); Label->SetJustification(ETextJustify::Center);
    FSlateFontInfo Font=Label->GetFont(); Font.Size=18; Label->SetFont(Font); Label->SetColorAndOpacity(FSlateColor(FLinearColor::White));
    B->SetContent(Label); ContentScroll->AddChild(B); B->SetAction(MoveTemp(Action));
}
void UBRFrontendWidget::AddNavigation()
{
    AddButton(TEXT("LOBBY"),[this]{ShowPage(EBRFrontendPage::Lobby);});
    AddButton(TEXT("MODES"),[this]{ShowPage(EBRFrontendPage::Modes);});
    AddButton(TEXT("MAPS"),[this]{ShowPage(EBRFrontendPage::Maps);});
    AddButton(TEXT("CHARACTERS"),[this]{ShowPage(EBRFrontendPage::Characters);});
    AddButton(TEXT("PETS"),[this]{ShowPage(EBRFrontendPage::Pets);});
    AddButton(TEXT("STORE"),[this]{ShowPage(EBRFrontendPage::Store);});
    AddButton(TEXT("VAULT"),[this]{ShowPage(EBRFrontendPage::Vault);});
    AddButton(TEXT("LUCK ROYALE"),[this]{ShowPage(EBRFrontendPage::LuckRoyale);});
    AddButton(TEXT("PROFILE"),[this]{ShowPage(EBRFrontendPage::Profile);});
    AddButton(TEXT("SETTINGS"),[this]{ShowPage(EBRFrontendPage::Settings);});
}
void UBRFrontendWidget::RebuildPage()
{
    if (!ContentScroll) return; ContentScroll->ClearChildren();
    FString Title;
    switch(CurrentPage) {
        case EBRFrontendPage::Lobby: Title=TEXT("Experience of Old Free Fire | OFFLINE LOBBY"); break;
        case EBRFrontendPage::Modes: Title=TEXT("SELECT GAME MODE"); break;
        case EBRFrontendPage::Maps: Title=TEXT("SELECT ISLAND MAP"); break;
        case EBRFrontendPage::Characters: Title=TEXT("CHARACTER COLLECTION"); break;
        case EBRFrontendPage::Pets: Title=TEXT("PET COLLECTION"); break;
        case EBRFrontendPage::Store: Title=TEXT("STORE"); break;
        case EBRFrontendPage::Vault: Title=TEXT("VAULT / INVENTORY"); break;
        case EBRFrontendPage::LuckRoyale: Title=TEXT("LUCK ROYALE"); break;
        case EBRFrontendPage::Profile: Title=TEXT("PLAYER PROFILE"); break;
        case EBRFrontendPage::Settings: Title=TEXT("SETTINGS"); break;
    }
    AddLabel(Title,30);
    UBRMetaProgressionSubsystem* Meta=GetGameInstance()?GetGameInstance()->GetSubsystem<UBRMetaProgressionSubsystem>():nullptr;
    if (CurrentPage==EBRFrontendPage::Lobby)
    {
        if (Meta) { const FBRPlayerProfile P=Meta->GetProfile(); AddLabel(FString::Printf(TEXT("%s  |  Lv.%d  |  Gold %d  |  Diamonds %d"),*P.Nickname,P.Level,P.Coins,P.Diamonds),20); }
        AddLabel(TEXT("Experience of Old Free Fire • OFFLINE • classic-era inspired build"),15);
        if (Meta) AddLabel(FString::Printf(TEXT("Selected map: %s"), Meta->GetSelectedMap()==EBRMapId::Bermuda?TEXT("Bermuda (greybox) "):TEXT("Purgatory (greybox)")),18);
        AddButton(TEXT("SELECT MAP"),[this]{ShowPage(EBRFrontendPage::Maps);});
        AddButton(TEXT("▶ START OFFLINE MATCH"),[this]{StartOfflineMatch();});
        AddNavigation(); return;
    }
    AddButton(TEXT("← BACK TO LOBBY"),[this]{ShowPage(EBRFrontendPage::Lobby);});
    if (!Meta) { AddLabel(TEXT("Profile subsystem is not available.")); return; }
    if (CurrentPage==EBRFrontendPage::Maps) {
        AddButton(TEXT("BERMUDA ISLAND — SELECT"),[this,Meta]{Meta->SelectMap(EBRMapId::Bermuda);ShowPage(EBRFrontendPage::Lobby);});
        AddButton(TEXT("PURGATORY ISLAND — SELECT"),[this,Meta]{Meta->SelectMap(EBRMapId::Purgatory);ShowPage(EBRFrontendPage::Lobby);});
        AddLabel(TEXT("These are original greybox layout variants, not copied official map assets."),14);
    } else if (CurrentPage==EBRFrontendPage::Profile) {
        const FBRPlayerProfile P=Meta->GetProfile(); AddLabel(FString::Printf(TEXT("Player: %s | Level %d | XP %d"),*P.Nickname,P.Level,P.Experience));
        AddLabel(FString::Printf(TEXT("Coins: %d | Diamonds: %d"),P.Coins,P.Diamonds)); AddLabel(FString::Printf(TEXT("BR: %d matches / %d wins   CS: %d matches / %d wins"),P.BRMatches,P.BRWins,P.CSMatches,P.CSWins));
        AddButton(TEXT("Set nickname to Player_2019"),[this,Meta]{Meta->SetNickname(TEXT("Player_2019"));RebuildPage();});
    } else if (CurrentPage==EBRFrontendPage::Modes) {
        for (const FBRModeDefinition& D:Meta->GetModeDefinitions()) { const EBRGameMode M=D.Mode; AddButton(FString::Printf(TEXT("%s  | %d players | team %d%s"),*D.DisplayName.ToString(),D.TargetPlayers,D.TeamSize,D.bRanked?TEXT(" | RANKED"):TEXT("")),[this,Meta,M]{Meta->SelectMode(M);ShowPage(EBRFrontendPage::Lobby);}); }
    } else if (CurrentPage==EBRFrontendPage::Characters) {
        for (const FBRCharacterDefinition& D:Meta->GetCharacterCatalog()) { const FName Id=D.Id; const bool Owned=Meta->OwnsItem(Id); AddButton(FString::Printf(TEXT("%s | ability %d | %s"),*D.DisplayName.ToString(),(int32)D.Ability,Owned?TEXT("OWNED / SELECT"):TEXT("BUY WITH COINS")),[this,Meta,Id,Owned]{if(Owned)Meta->SelectCharacter(Id);else Meta->PurchaseItem(Id,false);ShowPage(EBRFrontendPage::Characters);}); }
    } else if (CurrentPage==EBRFrontendPage::Pets) {
        AddButton(TEXT("Unequip pet"),[this,Meta]{Meta->SelectPet(NAME_None);ShowPage(EBRFrontendPage::Pets);});
        for (const FBRPetDefinition& D:Meta->GetPetCatalog()) { const FName Id=D.Id; const bool Owned=Meta->OwnsItem(Id); AddButton(FString::Printf(TEXT("%s | ability %d | %s"),*D.DisplayName.ToString(),(int32)D.Ability,Owned?TEXT("OWNED / SELECT"):TEXT("BUY WITH COINS")),[this,Meta,Id,Owned]{if(Owned)Meta->SelectPet(Id);else Meta->PurchaseItem(Id,false);ShowPage(EBRFrontendPage::Pets);}); }
    } else if (CurrentPage==EBRFrontendPage::Store) {
        for (const FBRStoreItem& I:Meta->GetStoreCatalog()) { const FName Id=I.Id; const bool Owned=Meta->OwnsItem(Id); AddButton(FString::Printf(TEXT("%s | gold %d | diamonds %d | %s"),*I.DisplayName.ToString(),I.CoinPrice,I.DiamondPrice,Owned?TEXT("OWNED"):TEXT("PURCHASE")),[this,Meta,Id,Owned]{if(!Owned){if(!Meta->PurchaseItem(Id,false))Meta->PurchaseItem(Id,true);}ShowPage(EBRFrontendPage::Store);}); }
    } else if (CurrentPage==EBRFrontendPage::Vault) {
        AddLabel(TEXT("Owned items — tap to equip")); for (FName Id:Meta->GetOwnedItems()) AddButton(Id.ToString(),[this,Meta,Id]{Meta->EquipItem(Id);ShowPage(EBRFrontendPage::Vault);});
        AddLabel(TEXT("Equipped items")); for (FName Id:Meta->GetEquippedItems()) AddLabel(Id.ToString(),15);
    } else if (CurrentPage==EBRFrontendPage::LuckRoyale) {
        for (const FBRLuckRoyaleOffer& O:Meta->GetLuckRoyaleOffers()) { const EBRLuckRoyaleType Type=O.Type; AddLabel(FString::Printf(TEXT("%s | gold %d | diamonds %d | spins %d"),*O.DisplayName.ToString(),O.GoldCost,O.DiamondCost,Meta->GetRoyaleSpinCount(Type))); AddButton(FString::Printf(TEXT("SPIN %s"),*O.DisplayName.ToString()),[this,Meta,Type,O]{const bool UseDiamonds=O.DiamondCost>0; const FBRRoyaleResult R=Meta->SpinLuckRoyale(Type,UseDiamonds); if(!R.RewardId.IsNone()) AddLabel(FString::Printf(TEXT("REWARD: %s%s"),*R.RewardName.ToString(),R.bDuplicate?TEXT(" (duplicate compensation)"):TEXT("")),18); else AddLabel(TEXT("Spin failed: insufficient currency or empty reward pool."),14);}); }
    } else if (CurrentPage==EBRFrontendPage::Settings) {
        FBRGameSettings S=Meta->GetSettings();
        AddLabel(TEXT("AUDIO"),22);
        AddLabel(FString::Printf(TEXT("Master %.0f%% | Music %.0f%% | SFX %.0f%%"),S.MasterVolume*100.f,S.MusicVolume*100.f,S.SFXVolume*100.f));
        AddButton(TEXT("Master volume +10%"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.MasterVolume=FMath::Clamp(X.MasterVolume+0.1f,0.f,1.f);Meta->SetSettings(X);UpdateLobbyRingtoneVolume();ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("Master volume -10%"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.MasterVolume=FMath::Clamp(X.MasterVolume-0.1f,0.f,1.f);Meta->SetSettings(X);UpdateLobbyRingtoneVolume();ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("Music volume +10%"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.MusicVolume=FMath::Clamp(X.MusicVolume+0.1f,0.f,1.f);Meta->SetSettings(X);UpdateLobbyRingtoneVolume();ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("SFX volume +10%"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.SFXVolume=FMath::Clamp(X.SFXVolume+0.1f,0.f,1.f);Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("Replay classic lobby ringtone"),[this]{if(LobbyMusicComponent){LobbyMusicComponent->Stop();LobbyMusicComponent=nullptr;}StartLobbyRingtone();});
        AddButton(TEXT("Music volume -10%"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.MusicVolume=FMath::Clamp(X.MusicVolume-0.1f,0.f,1.f);Meta->SetSettings(X);UpdateLobbyRingtoneVolume();ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("SFX volume -10%"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.SFXVolume=FMath::Clamp(X.SFXVolume-0.1f,0.f,1.f);Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddLabel(TEXT("CONTROLS & GAMEPLAY"),22);
        AddLabel(FString::Printf(TEXT("Look %.1f | Aim %.1f | HUD %d%% | Minimap %d"),S.LookSensitivity,S.AimSensitivity,S.HUDScale,S.MinimapSize));
        AddButton(TEXT("Look sensitivity +"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.LookSensitivity=FMath::Clamp(X.LookSensitivity+0.2f,0.1f,5.f);Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("Aim sensitivity +"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.AimSensitivity=FMath::Clamp(X.AimSensitivity+0.2f,0.1f,5.f);Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Aim Assist: %s"),S.bAimAssist?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bAimAssist=!X.bAimAssist;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Auto Pickup: %s"),S.bAutoPickup?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bAutoPickup=!X.bAutoPickup;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Left Fire Button: %s"),S.bLeftFireButton?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bLeftFireButton=!X.bLeftFireButton;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Quick Weapon Switch: %s"),S.bQuickWeaponSwitch?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bQuickWeaponSwitch=!X.bQuickWeaponSwitch;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Auto Parachute: %s"),S.bAutoParachute?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bAutoParachute=!X.bAutoParachute;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddLabel(TEXT("DISPLAY & PERFORMANCE"),22);
        AddLabel(FString::Printf(TEXT("Graphics %d | Shadows %d | Textures %d | FPS %d"),S.GraphicsQuality,S.ShadowQuality,S.TextureQuality,S.FPSLimit));
        AddButton(TEXT("Graphics Quality: cycle"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.GraphicsQuality=(X.GraphicsQuality+1)%4;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("Shadow Quality: cycle"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.ShadowQuality=(X.ShadowQuality+1)%4;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("Texture Quality: cycle"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.TextureQuality=(X.TextureQuality+1)%4;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("FPS Limit: cycle 30/45/60/90"),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.FPSLimit=(X.FPSLimit==30?45:X.FPSLimit==45?60:X.FPSLimit==60?90:30);Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Low Power Mode: %s"),S.bLowPowerMode?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bLowPowerMode=!X.bLowPowerMode;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Vibration: %s"),S.bVibration?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bVibration=!X.bVibration;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Damage Numbers: %s"),S.bDamageNumbers?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bDamageNumbers=!X.bDamageNumbers;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(FString::Printf(TEXT("Hit Markers: %s"),S.bHitMarkers?TEXT("ON"):TEXT("OFF")),[this,Meta]{FBRGameSettings X=Meta->GetSettings();X.bHitMarkers=!X.bHitMarkers;Meta->SetSettings(X);ShowPage(EBRFrontendPage::Settings);});
        AddButton(TEXT("Reset settings to defaults"),[this,Meta]{Meta->SetSettings(FBRGameSettings{});ShowPage(EBRFrontendPage::Settings);});
        AddLabel(TEXT("Note: settings are saved locally; options that require final audio/graphics/input systems are stored but not all are wired into runtime yet."),13);
    }
    AddNavigation();
}
void UBRFrontendWidget::StartOfflineMatch()
{
    if (AExperienceOfOldFreeFireGameMode* GM = GetWorld() ? Cast<AExperienceOfOldFreeFireGameMode>(UGameplayStatics::GetGameMode(this)) : nullptr) GM->StartOfflineMatch();
    if (APlayerController* PC=GetWorld()?GetWorld()->GetFirstPlayerController():nullptr)
    {
        UGameplayStatics::SetGamePaused(GetWorld(),false);
        PC->bShowMouseCursor=false; PC->SetInputMode(FInputModeGameAndUI()); PC->SetIgnoreMoveInput(false); PC->SetIgnoreLookInput(false);
    }
    RemoveFromParent();
}
