#include "BRMetaProgressionSubsystem.h"
#include "Kismet/GameplayStatics.h"

namespace { const TCHAR* SaveSlot = TEXT("Experience_of_Old_Free_Fire_Profile"); constexpr int32 SaveUserIndex = 0; }

void UBRMetaProgressionSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);
    BuildCatalog();
    BuildLuckRoyaleOffers();
    CharacterCatalog.Reset();
    auto AddCharacter=[this](const TCHAR* Id,const TCHAR* Name,EBRCharacterAbility Ability,float Value,float Cooldown){ FBRCharacterDefinition D; D.Id=FName(Id); D.DisplayName=FText::FromString(Name); D.Ability=Ability; D.AbilityValue=Value; D.CooldownSeconds=Cooldown; CharacterCatalog.Add(D); };
    AddCharacter(TEXT("char_recruit"),TEXT("Recruit"),EBRCharacterAbility::None,0.f,30.f);
    AddCharacter(TEXT("char_scout"),TEXT("Scout"),EBRCharacterAbility::SprintBoost,0.15f,25.f);
    AddCharacter(TEXT("char_medic"),TEXT("Field Medic"),EBRCharacterAbility::HealingAura,20.f,45.f);
    AddCharacter(TEXT("char_guard"),TEXT("Guardian"),EBRCharacterAbility::ArmorBoost,15.f,40.f);
    AddCharacter(TEXT("char_tracker"),TEXT("Tracker"),EBRCharacterAbility::ScanPulse,1800.f,50.f);
    PetCatalog.Reset();
    auto AddPet=[this](const TCHAR* Id,const TCHAR* Name,EBRPetAbility Ability,float Value){ FBRPetDefinition D; D.Id=FName(Id); D.DisplayName=FText::FromString(Name); D.Ability=Ability; D.AbilityValue=Value; PetCatalog.Add(D); };
    AddPet(TEXT("pet_fox"),TEXT("Ember Fox"),EBRPetAbility::MedkitBonus,10.f);
    AddPet(TEXT("pet_drone"),TEXT("Pocket Drone"),EBRPetAbility::AmmoFinder,0.15f);
    AddPet(TEXT("pet_turtle"),TEXT("Stone Turtle"),EBRPetAbility::CooldownBoost,0.10f);
    AddPet(TEXT("pet_gull"),TEXT("Coast Gull"),EBRPetAbility::ZoneWarning,8.f);
    LoadProgress();
    for (const FBRStoreItem& Item : StoreCatalog)
        if (Item.bDefaultOwned && !OwnedItems.Contains(Item.Id)) OwnedItems.Add(Item.Id);
}

void UBRMetaProgressionSubsystem::BuildCatalog()
{
    StoreCatalog.Reset();
    auto Add = [this](const TCHAR* Id, const TCHAR* Name, EBRStoreCategory Category, int32 Coins, int32 Diamonds, bool DefaultOwned=false)
    { FBRStoreItem I; I.Id=FName(Id); I.DisplayName=FText::FromString(Name); I.Category=Category; I.CoinPrice=Coins; I.DiamondPrice=Diamonds; I.bDefaultOwned=DefaultOwned; StoreCatalog.Add(I); };
    // Original placeholder entries: replace with licensed/original art and balanced economy before release.
    Add(TEXT("char_recruit"), TEXT("Recruit"), EBRStoreCategory::Character, 0, 0, true);
    Add(TEXT("char_scout"), TEXT("Scout"), EBRStoreCategory::Character, 2500, 0);
    Add(TEXT("char_medic"), TEXT("Field Medic"), EBRStoreCategory::Character, 4000, 0);
    Add(TEXT("pet_fox"), TEXT("Ember Fox"), EBRStoreCategory::Pet, 3000, 0);
    Add(TEXT("pet_drone"), TEXT("Pocket Drone"), EBRStoreCategory::Pet, 0, 99);
    Add(TEXT("outfit_classic"), TEXT("Classic Streetwear"), EBRStoreCategory::Outfit, 1200, 0);
    Add(TEXT("outfit_tactical"), TEXT("Tactical Set"), EBRStoreCategory::Outfit, 3500, 0);
    Add(TEXT("skin_rifle_sand"), TEXT("Sandstorm Rifle Finish"), EBRStoreCategory::WeaponSkin, 2200, 0);
    Add(TEXT("emote_wave"), TEXT("Wave"), EBRStoreCategory::Emote, 500, 0, true);
    Add(TEXT("crate_supply"), TEXT("Supply Crate"), EBRStoreCategory::LootCrate, 800, 0);
    Add(TEXT("voucher_gold"), TEXT("Gold Royale Voucher"), EBRStoreCategory::Voucher, 0, 49);
    Add(TEXT("voucher_weapon"), TEXT("Weapon Royale Voucher"), EBRStoreCategory::Voucher, 0, 59);
    Add(TEXT("token_incubator"), TEXT("Incubator Token"), EBRStoreCategory::RoyaleToken, 0, 19);
    Add(TEXT("crate_legacy"), TEXT("Legacy Returns Crate"), EBRStoreCategory::LootCrate, 1200, 0);
}

const FBRStoreItem* UBRMetaProgressionSubsystem::FindItem(FName ItemId) const
{ return StoreCatalog.FindByPredicate([ItemId](const FBRStoreItem& I){ return I.Id == ItemId; }); }

bool UBRMetaProgressionSubsystem::SetNickname(const FString& NewName)
{
    const FString Clean = NewName.TrimStartAndEnd();
    if (Clean.Len() < 3 || Clean.Len() > 16) return false;
    for (TCHAR C : Clean) if (!(FChar::IsAlnum(C) || C == TEXT('_'))) return false;
    Profile.Nickname = Clean; SaveProgress(); return true;
}

void UBRMetaProgressionSubsystem::AddExperience(int32 Amount)
{
    if (Amount <= 0) return;
    Profile.Experience += Amount;
    while (Profile.Experience >= Profile.Level * 1000) { Profile.Experience -= Profile.Level * 1000; ++Profile.Level; }
    SaveProgress();
}

TArray<EBRGameMode> UBRMetaProgressionSubsystem::GetAvailableModes() const
{ return { EBRGameMode::BRClassic, EBRGameMode::BRRanked, EBRGameMode::ClashSquad, EBRGameMode::ClashSquadRanked, EBRGameMode::RushHour, EBRGameMode::Training, EBRGameMode::LoneWolf }; }

TArray<FBRModeDefinition> UBRMetaProgressionSubsystem::GetModeDefinitions() const
{
    TArray<FBRModeDefinition> Result;
    auto AddMode = [&Result](EBRGameMode Mode, const TCHAR* Name, bool Ranked, int32 Players, int32 TeamSize, bool SafeZone)
    {
        FBRModeDefinition D; D.Mode=Mode; D.DisplayName=FText::FromString(Name); D.bRanked=Ranked;
        D.TargetPlayers=Players; D.TeamSize=TeamSize; D.bUsesSafeZone=SafeZone; Result.Add(D);
    };
    AddMode(EBRGameMode::BRClassic, TEXT("Classic Battle Royale"), false, 50, 1, true);
    AddMode(EBRGameMode::BRRanked, TEXT("Ranked Battle Royale"), true, 50, 1, true);
    AddMode(EBRGameMode::ClashSquad, TEXT("Clash Squad 4v4"), false, 8, 4, false);
    AddMode(EBRGameMode::ClashSquadRanked, TEXT("Ranked Clash Squad 4v4"), true, 8, 4, false);
    AddMode(EBRGameMode::RushHour, TEXT("Rush Hour"), false, 50, 1, true);
    AddMode(EBRGameMode::Training, TEXT("Training Ground"), false, 1, 1, false);
    AddMode(EBRGameMode::LoneWolf, TEXT("Lone Wolf Duel (inspired)"), false, 2, 1, false);
    return Result;
}

TArray<EBRMapId> UBRMetaProgressionSubsystem::GetAvailableMaps() const
{ return { EBRMapId::Bermuda, EBRMapId::Purgatory }; }

void UBRMetaProgressionSubsystem::BuildLuckRoyaleOffers()
{
    LuckRoyaleOffers.Reset();
    auto AddOffer=[this](EBRLuckRoyaleType Type, const TCHAR* Name, int32 Gold, int32 Diamonds)
    { FBRLuckRoyaleOffer O; O.Type=Type; O.DisplayName=FText::FromString(Name); O.GoldCost=Gold; O.DiamondCost=Diamonds; LuckRoyaleOffers.Add(O); };
    AddOffer(EBRLuckRoyaleType::GoldRoyale, TEXT("Gold Royale"), 300, 0);
    AddOffer(EBRLuckRoyaleType::DiamondRoyale, TEXT("Diamond Royale"), 0, 50);
    AddOffer(EBRLuckRoyaleType::WeaponRoyale, TEXT("Weapon Royale"), 0, 50);
    AddOffer(EBRLuckRoyaleType::Incubator, TEXT("Incubator"), 0, 60);
    AddOffer(EBRLuckRoyaleType::LegacyReturns, TEXT("Legacy Returns"), 0, 40);
}

TArray<FBRLuckRoyaleOffer> UBRMetaProgressionSubsystem::GetLuckRoyaleOffers() const
{ return LuckRoyaleOffers; }
void UBRMetaProgressionSubsystem::SelectMode(EBRGameMode Mode) { SelectedMode = Mode; SaveProgress(); }
void UBRMetaProgressionSubsystem::SelectMap(EBRMapId Map) { SelectedMap = Map; SaveProgress(); }

bool UBRMetaProgressionSubsystem::PurchaseItem(FName ItemId, bool bUseDiamonds)
{
    const FBRStoreItem* Item = FindItem(ItemId);
    if (!Item || OwnedItems.Contains(ItemId)) return false;
    const int32 Price = bUseDiamonds ? Item->DiamondPrice : Item->CoinPrice;
    if (Price <= 0) return false; // Prevents using the wrong currency for free/unsupported offers.
    if (bUseDiamonds) { if (Profile.Diamonds < Price) return false; Profile.Diamonds -= Price; }
    else { if (Profile.Coins < Price) return false; Profile.Coins -= Price; }
    OwnedItems.Add(ItemId); SaveProgress(); return true;
}

bool UBRMetaProgressionSubsystem::EquipItem(FName ItemId)
{
    if (!OwnedItems.Contains(ItemId)) return false;
    const FBRStoreItem* Item = FindItem(ItemId); if (!Item) return false;
    // One equipped item per category, except emotes/vouchers/crates which can be collected.
    if (Item->Category == EBRStoreCategory::Voucher || Item->Category == EBRStoreCategory::LootCrate) return false;
    for (int32 I=EquippedItems.Num()-1; I>=0; --I)
    { const FBRStoreItem* Existing=FindItem(EquippedItems[I]); if (Existing && Existing->Category==Item->Category) EquippedItems.RemoveAt(I); }
    EquippedItems.Add(ItemId); SaveProgress(); return true;
}

void UBRMetaProgressionSubsystem::SetSettings(const FBRGameSettings& NewSettings)
{
    Settings=NewSettings; Settings.MasterVolume=FMath::Clamp(Settings.MasterVolume,0.f,1.f); Settings.MusicVolume=FMath::Clamp(Settings.MusicVolume,0.f,1.f); Settings.SFXVolume=FMath::Clamp(Settings.SFXVolume,0.f,1.f); Settings.LookSensitivity=FMath::Clamp(Settings.LookSensitivity,0.1f,5.f); Settings.AimSensitivity=FMath::Clamp(Settings.AimSensitivity,0.1f,5.f); Settings.GraphicsQuality=FMath::Clamp(Settings.GraphicsQuality,0,3); Settings.ShadowQuality=FMath::Clamp(Settings.ShadowQuality,0,3); Settings.TextureQuality=FMath::Clamp(Settings.TextureQuality,0,3); Settings.FPSLimit=(Settings.FPSLimit==30||Settings.FPSLimit==45||Settings.FPSLimit==60||Settings.FPSLimit==90)?Settings.FPSLimit:60; Settings.MinimapSize=FMath::Clamp(Settings.MinimapSize,0,2); Settings.HUDScale=FMath::Clamp(Settings.HUDScale,70,130); SaveProgress();
}

void UBRMetaProgressionSubsystem::RecordMatchResult(bool bClashSquad, bool bWon)
{
    if (bClashSquad) { ++Profile.CSMatches; if (bWon) ++Profile.CSWins; }
    else { ++Profile.BRMatches; if (bWon) ++Profile.BRWins; }
    AddExperience(bWon ? 250 : 75); SaveProgress();
}

void UBRMetaProgressionSubsystem::SaveProgress()
{
    UBRMetaSaveGame* Save=Cast<UBRMetaSaveGame>(UGameplayStatics::CreateSaveGameObject(UBRMetaSaveGame::StaticClass())); if (!Save) return;
    Save->Profile=Profile; Save->Settings=Settings; Save->OwnedItems=OwnedItems; Save->EquippedItems=EquippedItems; Save->SelectedMode=SelectedMode; Save->SelectedMap=SelectedMap; Save->SelectedCharacter=SelectedCharacter; Save->SelectedPet=SelectedPet; Save->RoyaleSpinCounts=RoyaleSpinCounts;
    UGameplayStatics::SaveGameToSlot(Save,SaveSlot,SaveUserIndex);
}
void UBRMetaProgressionSubsystem::LoadProgress()
{
    if (!UGameplayStatics::DoesSaveGameExist(SaveSlot,SaveUserIndex)) return;
    UBRMetaSaveGame* Save=Cast<UBRMetaSaveGame>(UGameplayStatics::LoadGameFromSlot(SaveSlot,SaveUserIndex)); if (!Save) return;
    Profile=Save->Profile; Settings=Save->Settings; OwnedItems=Save->OwnedItems; EquippedItems=Save->EquippedItems; SelectedMode=Save->SelectedMode; SelectedMap=Save->SelectedMap; SelectedCharacter=Save->SelectedCharacter; SelectedPet=Save->SelectedPet; RoyaleSpinCounts=Save->RoyaleSpinCounts;
}

TArray<FBRCharacterDefinition> UBRMetaProgressionSubsystem::GetCharacterCatalog() const { return CharacterCatalog; }
TArray<FBRPetDefinition> UBRMetaProgressionSubsystem::GetPetCatalog() const { return PetCatalog; }
bool UBRMetaProgressionSubsystem::SelectCharacter(FName CharacterId)
{
    const bool bKnown=CharacterCatalog.ContainsByPredicate([CharacterId](const FBRCharacterDefinition& D){ return D.Id==CharacterId; });
    if (!bKnown || !OwnedItems.Contains(CharacterId)) return false; SelectedCharacter=CharacterId; SaveProgress(); return true;
}
bool UBRMetaProgressionSubsystem::SelectPet(FName PetId)
{
    if (PetId.IsNone()) { SelectedPet=NAME_None; SaveProgress(); return true; }
    const bool bKnown=PetCatalog.ContainsByPredicate([PetId](const FBRPetDefinition& D){ return D.Id==PetId; });
    if (!bKnown || !OwnedItems.Contains(PetId)) return false; SelectedPet=PetId; SaveProgress(); return true;
}
int32 UBRMetaProgressionSubsystem::GetRoyaleSpinCount(EBRLuckRoyaleType Type) const
{ const int32* Count=RoyaleSpinCounts.Find((uint8)Type); return Count ? *Count : 0; }
FBRRoyaleResult UBRMetaProgressionSubsystem::SpinLuckRoyale(EBRLuckRoyaleType Type, bool bUseDiamonds)
{
    FBRRoyaleResult Result;
    const FBRLuckRoyaleOffer* Offer=LuckRoyaleOffers.FindByPredicate([Type](const FBRLuckRoyaleOffer& O){ return O.Type==Type; });
    if (!Offer) return Result;
    const int32 Cost=bUseDiamonds ? Offer->DiamondCost : Offer->GoldCost;
    if (Cost<=0) return Result;
    if (bUseDiamonds) { if (Profile.Diamonds<Cost) return Result; Profile.Diamonds-=Cost; }
    else { if (Profile.Coins<Cost) return Result; Profile.Coins-=Cost; }
    TArray<const FBRStoreItem*> Pool;
    for (const FBRStoreItem& Item:StoreCatalog) { if ((Type==EBRLuckRoyaleType::WeaponRoyale && Item.Category==EBRStoreCategory::WeaponSkin) || (Type==EBRLuckRoyaleType::Incubator && (Item.Category==EBRStoreCategory::RoyaleToken || Item.Category==EBRStoreCategory::Outfit)) || (Type==EBRLuckRoyaleType::GoldRoyale && (Item.Category==EBRStoreCategory::Voucher || Item.Category==EBRStoreCategory::LootCrate || Item.Category==EBRStoreCategory::Emote)) || (Type==EBRLuckRoyaleType::DiamondRoyale && (Item.Category==EBRStoreCategory::Character || Item.Category==EBRStoreCategory::Outfit)) || (Type==EBRLuckRoyaleType::LegacyReturns && (Item.Category==EBRStoreCategory::LootCrate || Item.Category==EBRStoreCategory::Outfit))) Pool.Add(&Item); }
    if (Pool.Num()==0) { Profile.Coins+=bUseDiamonds?0:Cost; Profile.Diamonds+=bUseDiamonds?Cost:0; return Result; }
    const FBRStoreItem* Won=Pool[FMath::RandRange(0,Pool.Num()-1)]; Result.RewardId=Won->Id; Result.RewardName=Won->DisplayName; Result.bDuplicate=OwnedItems.Contains(Won->Id);
    if (Result.bDuplicate) { Result.CompensationCoins=250; Profile.Coins+=Result.CompensationCoins; } else { OwnedItems.Add(Won->Id); }
    int32& Count=RoyaleSpinCounts.FindOrAdd((uint8)Type); ++Count; SaveProgress(); return Result;
}
