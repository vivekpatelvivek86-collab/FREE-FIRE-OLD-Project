#include "ExperienceOfOldFreeFireGameMode.h"
#include "BRPlayerCharacter.h"
#include "BRBotCharacter.h"
#include "BRGameHUDWidget.h"
#include "BRFrontendWidget.h"
#include "BRMetaProgressionSubsystem.h"
#include "BRSafeZoneActor.h"
#include "BRLootPickup.h"
#include "BRWorldBuilderActor.h"
#include "BRPetCompanion.h"
#include "Blueprint/UserWidget.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "TimerManager.h"

AExperienceOfOldFreeFireGameMode::AExperienceOfOldFreeFireGameMode()
{
    PrimaryActorTick.bCanEverTick = true;
    DefaultPawnClass = ABRPlayerCharacter::StaticClass();
    BotClass = ABRBotCharacter::StaticClass();
    SafeZoneClass = ABRSafeZoneActor::StaticClass();
    LootClass = ABRLootPickup::StaticClass();
    WorldBuilderClass = ABRWorldBuilderActor::StaticClass();
}
void AExperienceOfOldFreeFireGameMode::BeginPlay()
{
    Super::BeginPlay(); ConfigureSelectedMode(); SpawnWorldSystems();
    if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
    {
        if (UBRGameHUDWidget* HUD = CreateWidget<UBRGameHUDWidget>(PC, UBRGameHUDWidget::StaticClass())) HUD->AddToViewport(10);
        if (UBRFrontendWidget* Frontend = CreateWidget<UBRFrontendWidget>(PC, UBRFrontendWidget::StaticClass()))
        {
            Frontend->AddToViewport(100);
            PC->bShowMouseCursor = true;
            PC->SetInputMode(FInputModeGameAndUI());
            UGameplayStatics::SetGamePaused(GetWorld(), true);
        }
        else { PC->bShowMouseCursor = false; }
    }
    // The lobby is shown first. Actual match actors are spawned only after the player presses Start.
    InitialMatchCombatants = InitialBotCount + 1;
}
void AExperienceOfOldFreeFireGameMode::ConfigureSelectedMode()
{
    if (UGameInstance* GI = GetGameInstance())
    {
        if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>())
        {
            switch (Meta->GetSelectedMode())
            {
                case EBRGameMode::BRClassic: case EBRGameMode::BRRanked: InitialBotCount=49; BotSpawnRadius=10000.f; break;
                case EBRGameMode::RushHour: InitialBotCount=19; BotSpawnRadius=7000.f; break;
                case EBRGameMode::ClashSquad: case EBRGameMode::ClashSquadRanked: InitialBotCount=7; BotSpawnRadius=1400.f; break;
                case EBRGameMode::LoneWolf: InitialBotCount=1; BotSpawnRadius=900.f; break;
                case EBRGameMode::Training: InitialBotCount=0; BotSpawnRadius=0.f; break;
                default: InitialBotCount=8; break;
            }
        }
    }
}
void AExperienceOfOldFreeFireGameMode::SpawnWorldSystems()
{
    // Keep the default player spawn clear of the central compound in an empty test level.
    if (ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0)))
        Player->SetActorLocation(FVector(0.f, -2400.f, 170.f));
}
void AExperienceOfOldFreeFireGameMode::StartOfflineMatch()
{
    if (bGameStarted || bMatchFinished || !GetWorld()) return;
    ConfigureSelectedMode();
    if (WorldBuilderClass) GetWorld()->SpawnActor<ABRWorldBuilderActor>(WorldBuilderClass, FVector::ZeroVector, FRotator::ZeroRotator);
    if (ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0)))
    {
        // The compact practice and duel layouts are centered on the lobby's existing test spawn.
        if (UGameInstance* GI = GetGameInstance())
        {
            if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>())
            {
                if (Meta->GetSelectedMode() == EBRGameMode::Training)
                    Player->SetActorLocation(FVector(0.f, -6500.f, 170.f));
                else if (Meta->GetSelectedMode() == EBRGameMode::LoneWolf)
                    Player->SetActorLocation(FVector(-4200.f, -2400.f, 170.f));
                else
                    Player->SetActorLocation(FVector(0.f, -2400.f, 170.f));
            }
        }
        Player->TeamId = 1;
        Player->Health = Player->MaxHealth;
        Player->TriggerPetPassive();
        if (UGameInstance* GI = GetGameInstance())
            if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>())
                if (!Meta->GetSelectedPet().IsNone())
                {
                    FActorSpawnParameters PetParams; PetParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
                    if (ABRPetCompanion* Pet = GetWorld()->SpawnActor<ABRPetCompanion>(ABRPetCompanion::StaticClass(), Player->GetActorLocation()+FVector(0,100,50), FRotator::ZeroRotator, PetParams)) Pet->FollowTarget = Player;
                }
    }
    SpawnOfflineBots();
    SpawnLoot();
    InitialMatchCombatants = InitialBotCount + 1;
    MatchElapsed = 0.f;
    bGameStarted = true;
    if (IsClashSquadMode()) SetupClashSquadTeams();
    else if (SafeZoneClass && InitialBotCount >= 19)
    {
        FActorSpawnParameters Params;
        Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        GetWorld()->SpawnActor<ABRSafeZoneActor>(SafeZoneClass, FVector::ZeroVector, FRotator::ZeroRotator, Params);
    }
}

void AExperienceOfOldFreeFireGameMode::SpawnOfflineBots()
{
    if (!BotClass || InitialBotCount <= 0) return;
    APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(this, 0);
    const FVector Origin = PlayerPawn ? PlayerPawn->GetActorLocation() : FVector::ZeroVector;
    for (int32 Index = 0; Index < InitialBotCount; ++Index)
    {
        const float Angle = (2.f * PI * Index) / FMath::Max(1, InitialBotCount);
        const float Radius = FMath::FRandRange(BotSpawnRadius * 0.55f, BotSpawnRadius);
        FVector SpawnLocation = Origin + FVector(FMath::Cos(Angle) * Radius, FMath::Sin(Angle) * Radius, 150.f);
        if (UGameInstance* GI = GetGameInstance())
        {
            if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>())
            {
                if (Meta->GetSelectedMode() == EBRGameMode::LoneWolf)
                    SpawnLocation = FVector(4200.f, -2400.f, 170.f);
                else if (Meta->GetSelectedMode() == EBRGameMode::Training)
                    SpawnLocation = FVector(0.f, 1200.f, 170.f);
            }
        }
        FHitResult GroundHit;
        if (GetWorld()->LineTraceSingleByChannel(GroundHit, SpawnLocation + FVector(0,0,2000.f), SpawnLocation - FVector(0,0,5000.f), ECC_Visibility)) SpawnLocation = GroundHit.ImpactPoint + FVector(0,0,100.f);
        FActorSpawnParameters Params; Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
        if (ABRBotCharacter* Bot = GetWorld()->SpawnActor<ABRBotCharacter>(BotClass, SpawnLocation, FRotator::ZeroRotator, Params)) Bot->Tags.AddUnique(FName("OfflineBot"));
    }
}
void AExperienceOfOldFreeFireGameMode::SpawnLoot()
{
    if (!LootClass || IsClashSquadMode()) return;
    const int32 LootCount = InitialBotCount == 0 ? 18 : (InitialBotCount >= 40 ? 100 : 45);
    for (int32 I=0; I<LootCount; ++I)
    {
        const float A=FMath::FRandRange(0.f,2.f*PI), R=FMath::Sqrt(FMath::FRand())*11500.f;
        FVector P(FMath::Cos(A)*R,FMath::Sin(A)*R,180.f);
        FHitResult Hit;
        if (GetWorld()->LineTraceSingleByChannel(Hit,P+FVector(0,0,2500),P-FVector(0,0,5000),ECC_Visibility)) P=Hit.ImpactPoint+FVector(0,0,55.f);
        FActorSpawnParameters Params; Params.SpawnCollisionHandlingOverride=ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
        if (ABRLootPickup* Loot=GetWorld()->SpawnActor<ABRLootPickup>(LootClass,P,FRotator::ZeroRotator,Params))
        {
            const int32 T = I % 4;
            Loot->LootType = static_cast<EBRLootType>(T);
            Loot->Amount = T == 0 ? 30 : (T == 1 ? 1 : (T == 2 ? 20 : 1));
        }
    }
}
void AExperienceOfOldFreeFireGameMode::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds); if (bMatchFinished || !bGameStarted || UGameplayStatics::IsGamePaused(this)) return;
    // Training is a persistent practice space: do not run battle-royale match-end timers there.
    if (UGameInstance* GI = GetGameInstance())
        if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>())
            if (Meta->GetSelectedMode() == EBRGameMode::Training) return;
    MatchElapsed+=DeltaSeconds;
    if (IsClashSquadMode()) { TickClashSquadRound(DeltaSeconds); return; }
    CheckMatchEnd();
    if (MatchElapsed>=MatchTimeLimitSeconds)
    {
        bMatchFinished=true;
        if (UGameInstance* GI=GetGameInstance()) if (UBRMetaProgressionSubsystem* Meta=GI->GetSubsystem<UBRMetaProgressionSubsystem>()) Meta->RecordMatchResult(false,false);
        if (APlayerController* PC=GetWorld()->GetFirstPlayerController()) PC->ClientMessage(TEXT("MATCH OVER - TIME LIMIT"));
    }
}
void AExperienceOfOldFreeFireGameMode::CheckMatchEnd()
{
    ABRPlayerCharacter* Player=Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if (!Player || Player->Health<=0.f)
    {
        bMatchFinished=true;
        if (UGameInstance* GI=GetGameInstance()) if (UBRMetaProgressionSubsystem* Meta=GI->GetSubsystem<UBRMetaProgressionSubsystem>()) Meta->RecordMatchResult(false,false);
        if (APlayerController* PC=GetWorld()->GetFirstPlayerController()) PC->ClientMessage(TEXT("ELIMINATED - MATCH OVER")); return;
    }
    TArray<AActor*> Bots; UGameplayStatics::GetAllActorsOfClass(this,ABRBotCharacter::StaticClass(),Bots);
    int32 LivingBots = 0;
    for (AActor* Actor : Bots) if (const ABRBotCharacter* Bot = Cast<ABRBotCharacter>(Actor)) if (Bot->Health > 0.f) ++LivingBots;
    if (LivingBots==0 && InitialMatchCombatants>1)
    {
        bMatchFinished=true;
        if (UGameInstance* GI=GetGameInstance()) if (UBRMetaProgressionSubsystem* Meta=GI->GetSubsystem<UBRMetaProgressionSubsystem>()) Meta->RecordMatchResult(false,true);
        if (APlayerController* PC=GetWorld()->GetFirstPlayerController()) PC->ClientMessage(TEXT("BOOYAH! - YOU WIN"));
    }
}


bool AExperienceOfOldFreeFireGameMode::IsClashSquadMode() const
{
    if (UGameInstance* GI = GetGameInstance())
        if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>())
            return Meta->GetSelectedMode() == EBRGameMode::ClashSquad || Meta->GetSelectedMode() == EBRGameMode::ClashSquadRanked;
    return false;
}

void AExperienceOfOldFreeFireGameMode::SetupClashSquadTeams()
{
    if (ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0))) Player->TeamId = 1;
    TArray<AActor*> Bots;
    UGameplayStatics::GetAllActorsOfClass(this, ABRBotCharacter::StaticClass(), Bots);
    // Three bots join the player (4 total); the remaining four bots form the opposing squad.
    for (int32 I = 0; I < Bots.Num(); ++I)
        if (ABRBotCharacter* Bot = Cast<ABRBotCharacter>(Bots[I])) Bot->TeamId = I < 3 ? 1 : 2;
}

int32 AExperienceOfOldFreeFireGameMode::CountLivingTeam(int32 TeamId) const
{
    int32 Count = 0;
    if (TeamId == 1)
        if (const ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0)))
            if (Player->Health > 0.f) ++Count;
    TArray<AActor*> Bots;
    UGameplayStatics::GetAllActorsOfClass(this, ABRBotCharacter::StaticClass(), Bots);
    for (AActor* Actor : Bots)
        if (const ABRBotCharacter* Bot = Cast<ABRBotCharacter>(Actor))
            if (Bot->Health > 0.f && Bot->TeamId == TeamId) ++Count;
    return Count;
}

void AExperienceOfOldFreeFireGameMode::TickClashSquadRound(float DeltaSeconds)
{
    if (bMatchFinished || bClashSquadRoundOver) return;
    ClashSquadRoundElapsed += DeltaSeconds;
    const int32 FriendlyAlive = CountLivingTeam(1);
    const int32 EnemyAlive = CountLivingTeam(2);
    bool bRoundResolved = false;
    bool bPlayerTeamWon = false;
    if (FriendlyAlive <= 0 || EnemyAlive <= 0)
    {
        bRoundResolved = true;
        bPlayerTeamWon = EnemyAlive <= 0 && FriendlyAlive > 0;
    }
    else if (ClashSquadRoundElapsed >= ClashSquadRoundDuration)
    {
        bRoundResolved = true;
        bPlayerTeamWon = FriendlyAlive > EnemyAlive;
    }
    if (!bRoundResolved) return;

    bClashSquadRoundOver = true;
    if (bPlayerTeamWon) ++PlayerTeamRoundsWon; else ++EnemyTeamRoundsWon;
    if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
        PC->ClientMessage(FString::Printf(TEXT("CLASH SQUAD ROUND %d COMPLETE - YOU %d : %d ENEMY"), ClashSquadRound, PlayerTeamRoundsWon, EnemyTeamRoundsWon));

    if (PlayerTeamRoundsWon >= ClashSquadRoundsToWin || EnemyTeamRoundsWon >= ClashSquadRoundsToWin)
    {
        bMatchFinished = true;
        const bool bWon = PlayerTeamRoundsWon >= ClashSquadRoundsToWin;
        if (UGameInstance* GI = GetGameInstance())
            if (UBRMetaProgressionSubsystem* Meta = GI->GetSubsystem<UBRMetaProgressionSubsystem>()) Meta->RecordMatchResult(true, bWon);
        if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
            PC->ClientMessage(bWon ? TEXT("CLASH SQUAD BOOYAH!") : TEXT("CLASH SQUAD DEFEAT"));
        return;
    }
    GetWorldTimerManager().SetTimerForNextTick(this, &AExperienceOfOldFreeFireGameMode::StartNextClashSquadRound);
}

void AExperienceOfOldFreeFireGameMode::StartNextClashSquadRound()
{
    if (bMatchFinished) return;
    ++ClashSquadRound;
    ClashSquadRoundElapsed = 0.f;
    bClashSquadRoundOver = false;
    TArray<AActor*> Bots;
    UGameplayStatics::GetAllActorsOfClass(this, ABRBotCharacter::StaticClass(), Bots);
    for (AActor* Actor : Bots) Actor->Destroy();
    if (ABRPlayerCharacter* Player = Cast<ABRPlayerCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0)))
    {
        Player->Health = Player->MaxHealth;
        Player->AmmoInMagazine = Player->MagazineSize;
        Player->TeamId = 1;
        Player->SetActorLocation(FVector(0.f, 0.f, 150.f));
    }
    for (int32 I = 0; I < 7; ++I)
    {
        const int32 Team = I < 3 ? 1 : 2;
        const float Angle = 2.f * PI * I / 7.f;
        const FVector Location(FMath::Cos(Angle) * 1100.f, FMath::Sin(Angle) * 1100.f, 150.f);
        FActorSpawnParameters Params; Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
        if (ABRBotCharacter* Bot = GetWorld()->SpawnActor<ABRBotCharacter>(BotClass, Location, FRotator::ZeroRotator, Params)) Bot->TeamId = Team;
    }
    if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
        PC->ClientMessage(FString::Printf(TEXT("CLASH SQUAD - ROUND %d START"), ClashSquadRound));
}
