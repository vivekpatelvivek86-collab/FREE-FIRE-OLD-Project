#include "BRActionButton.h"

UBRActionButton::UBRActionButton(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
    OnClicked.AddDynamic(this, &UBRActionButton::DispatchAction);
}
void UBRActionButton::SetAction(TFunction<void()> InAction)
{
    Action = MoveTemp(InAction);
}
void UBRActionButton::DispatchAction()
{
    if (Action) Action();
}
