using UnrealBuildTool;

public class ExperienceOfOldFreeFire : ModuleRules
{
    public ExperienceOfOldFreeFire(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "AIModule", "GameplayTasks", "NavigationSystem", "UMG", "Slate", "SlateCore" });
    }
}
