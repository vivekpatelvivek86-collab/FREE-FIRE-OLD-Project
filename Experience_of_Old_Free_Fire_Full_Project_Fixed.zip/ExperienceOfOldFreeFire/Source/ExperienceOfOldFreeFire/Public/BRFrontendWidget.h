#pragma once
#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "BRFrontendWidget.generated.h"

UENUM(BlueprintType)
enum class EBRFrontendPage : uint8 { Lobby, Modes, Maps, Characters, Pets, Store, Vault, LuckRoyale, Profile, Settings };

UCLASS()
class EXPERIENCEOFOLDFREEFIRE_API UBRFrontendWidget : public UUserWidget
{
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintCallable, Category="FF2019|Frontend") void ShowPage(EBRFrontendPage Page);
    UFUNCTION(BlueprintCallable, Category="FF2019|Frontend") EBRFrontendPage GetCurrentPage() const { return CurrentPage; }
    UFUNCTION(BlueprintCallable, Category="FF2019|Frontend") void StartOfflineMatch();
protected:
    virtual void NativeConstruct() override;
    virtual void NativeDestruct() override;
private:
    void RebuildPage();
    void AddLabel(const FString& Text, int32 Size=18);
    void AddButton(const FString& Text, TFunction<void()> Action);
    void AddNavigation();
    void StartLobbyRingtone();
    void UpdateLobbyRingtoneVolume();
    UPROPERTY() class UVerticalBox* RootBox = nullptr;
    UPROPERTY() class UScrollBox* ContentScroll = nullptr;
    UPROPERTY() class USoundWave* LobbyRingtone = nullptr;
    UPROPERTY() class UAudioComponent* LobbyMusicComponent = nullptr;
    UPROPERTY() EBRFrontendPage CurrentPage = EBRFrontendPage::Lobby;
};
