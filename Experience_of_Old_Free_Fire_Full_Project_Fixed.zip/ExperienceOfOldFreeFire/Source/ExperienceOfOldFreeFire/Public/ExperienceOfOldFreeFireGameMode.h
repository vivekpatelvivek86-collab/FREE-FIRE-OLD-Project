#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ExperienceOfOldFreeFireGameMode.generated.h"
class ABRBotCharacter;
class ABRSafeZoneActor;
class ABRLootPickup;
class ABRWorldBuilderActor;

UCLASS()
class EXPERIENCEOFOLDFREEFIRE_API AExperienceOfOldFreeFireGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    AExperienceOfOldFreeFireGameMode();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    UFUNCTION(BlueprintCallable, Category="Offline Match") void StartOfflineMatch();
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Offline Match", meta=(ClampMin="0", ClampMax="49")) int32 InitialBotCount = 49;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Offline Match") float BotSpawnRadius = 10000.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Offline Match") float MatchTimeLimitSeconds = 900.f;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Offline Match") TSubclassOf<ABRBotCharacter> BotClass;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Offline Match") TSubclassOf<ABRSafeZoneActor> SafeZoneClass;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Offline Match") TSubclassOf<ABRLootPickup> LootClass;
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Offline Match") TSubclassOf<ABRWorldBuilderActor> WorldBuilderClass;
private:
    void ConfigureSelectedMode();
    void SpawnOfflineBots();
    void SpawnWorldSystems();
    void SpawnLoot();
    void CheckMatchEnd();
    void SetupClashSquadTeams();
    void TickClashSquadRound(float DeltaSeconds);
    void StartNextClashSquadRound();
    int32 CountLivingTeam(int32 TeamId) const;
    bool IsClashSquadMode() const;
    float MatchElapsed = 0.f;
    bool bMatchFinished = false;
    bool bGameStarted = false;
    int32 InitialMatchCombatants = 50;
    int32 ClashSquadRound = 1;
    int32 ClashSquadRoundsToWin = 4;
    int32 PlayerTeamRoundsWon = 0;
    int32 EnemyTeamRoundsWon = 0;
    float ClashSquadRoundElapsed = 0.f;
    float ClashSquadRoundDuration = 100.f;
    bool bClashSquadRoundOver = false;
};
