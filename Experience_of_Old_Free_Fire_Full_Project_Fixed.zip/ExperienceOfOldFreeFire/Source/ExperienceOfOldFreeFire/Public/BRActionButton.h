#pragma once
#include "CoreMinimal.h"
#include "Components/Button.h"
#include "BRActionButton.generated.h"

/** Runtime-created UMG button that safely dispatches a native callback through a reflected click handler. */
UCLASS()
class EXPERIENCEOFOLDFREEFIRE_API UBRActionButton : public UButton
{
    GENERATED_BODY()
public:
    UBRActionButton(const FObjectInitializer& ObjectInitializer);
    void SetAction(TFunction<void()> InAction);
private:
    UFUNCTION() void DispatchAction();
    TFunction<void()> Action;
};
